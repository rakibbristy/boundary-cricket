extends Node3D

var runs: int = 0
var wickets: int = 0
var balls: int = 0
var ball_active: bool = false
var shot_played: bool = false
var shot_quality: float = 0.0
var ball_velocity: Vector3 = Vector3.ZERO

var ball_node: MeshInstance3D
var score_label: Label
var message_label: Label
var bowl_button: Button
var hit_button: Button
var batter: Node3D
var bowler: Node3D

func _ready() -> void:
	_build_environment()
	_build_ground()
	_build_players()
	_build_ball()
	_build_hud()
	_update_score()
	_set_message("Tap BOWL to start")

func _process(delta: float) -> void:
	if not ball_active:
		return
	ball_velocity.y -= 9.8 * delta
	ball_node.position += ball_velocity * delta
	ball_node.rotate_x(delta * 14.0)

	if ball_node.position.y <= 0.18:
		ball_node.position.y = 0.18
		ball_velocity.y = absf(ball_velocity.y) * 0.38
		ball_velocity.x *= 0.82
		ball_velocity.z *= 0.82
		if absf(ball_velocity.y) < 1.0:
			_finish_delivery()

	if absf(ball_node.position.x) > 30.0 or ball_node.position.z > 42.0 or ball_node.position.z < -42.0:
		_finish_delivery()

func _build_environment() -> void:
	var world := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	sky.sky_material = ProceduralSkyMaterial.new()
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.72, 0.78, 0.86)
	env.ambient_light_energy = 0.8
	world.environment = env
	add_child(world)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -28, 0)
	sun.light_energy = 1.2
	sun.shadow_enabled = true
	add_child(sun)

	var camera := Camera3D.new()
	camera.position = Vector3(0, 12, 22)
	camera.rotation_degrees = Vector3(-25, 0, 0)
	camera.current = true
	add_child(camera)

func _build_ground() -> void:
	_make_box("Outfield", Vector3(0, -0.35, 0), Vector3(64, 0.5, 86), Color(0.12, 0.42, 0.19))
	_make_box("Pitch", Vector3(0, -0.02, 0), Vector3(3.5, 0.16, 22), Color(0.68, 0.53, 0.35))
	_make_box("NearCrease", Vector3(0, 0.08, 8.5), Vector3(4.4, 0.04, 0.12), Color.WHITE)
	_make_box("FarCrease", Vector3(0, 0.08, -8.5), Vector3(4.4, 0.04, 0.12), Color.WHITE)

	for x in [-0.75, 0.0, 0.75]:
		_make_cylinder("NearWicket", Vector3(x, 0.82, 8.2), 0.12, 1.5, Color(0.92, 0.86, 0.7))
		_make_cylinder("FarWicket", Vector3(x, 0.82, -8.2), 0.12, 1.5, Color(0.92, 0.86, 0.7))

	for i in range(48):
		var angle := TAU * float(i) / 48.0
		var p := Vector3(cos(angle) * 29.0, 0.12, sin(angle) * 38.0)
		_make_box("BoundaryMarker", p, Vector3(0.55, 0.22, 0.55), Color(0.9, 0.88, 0.72))

func _build_players() -> void:
	batter = _make_player(Vector3(0, 0, 7.0), Color(0.12, 0.28, 0.82), true)
	bowler = _make_player(Vector3(0, 0, -15.0), Color(0.82, 0.16, 0.12), false)

func _make_player(pos: Vector3, shirt: Color, with_bat: bool) -> Node3D:
	var root := Node3D.new()
	root.position = pos
	add_child(root)
	_make_sphere_child(root, Vector3(0, 2.05, 0), Vector3(0.48, 0.55, 0.42), Color(0.72, 0.48, 0.32))
	_make_box_child(root, Vector3(0, 1.35, 0), Vector3(0.9, 1.15, 0.48), shirt)
	_make_box_child(root, Vector3(-0.24, 0.48, 0), Vector3(0.25, 0.85, 0.3), Color(0.12, 0.12, 0.16))
	_make_box_child(root, Vector3(0.24, 0.48, 0), Vector3(0.25, 0.85, 0.3), Color(0.12, 0.12, 0.16))
	if with_bat:
		var bat := _make_box_child(root, Vector3(0.7, 1.05, -0.15), Vector3(0.16, 1.55, 0.12), Color(0.72, 0.48, 0.22))
		bat.rotation_degrees.z = -18
	return root

func _build_ball() -> void:
	ball_node = MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = 0.18
	sphere.height = 0.36
	ball_node.mesh = sphere
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.85, 0.05, 0.06)
	mat.roughness = 0.45
	ball_node.material_override = mat
	ball_node.position = Vector3(0, 0.18, -8)
	add_child(ball_node)

func _build_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)

	var top_panel := PanelContainer.new()
	top_panel.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top_panel.offset_bottom = 76
	layer.add_child(top_panel)

	var top_row := HBoxContainer.new()
	top_row.add_theme_constant_override("separation", 20)
	top_panel.add_child(top_row)

	score_label = Label.new()
	score_label.add_theme_font_size_override("font_size", 25)
	score_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top_row.add_child(score_label)

	message_label = Label.new()
	message_label.add_theme_font_size_override("font_size", 20)
	message_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top_row.add_child(message_label)

	var controls := HBoxContainer.new()
	controls.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	controls.alignment = BoxContainer.ALIGNMENT_CENTER
	controls.offset_top = -105
	controls.offset_bottom = -15
	controls.add_theme_constant_override("separation", 28)
	layer.add_child(controls)

	bowl_button = Button.new()
	bowl_button.text = "BOWL"
	bowl_button.custom_minimum_size = Vector2(220, 82)
	bowl_button.add_theme_font_size_override("font_size", 28)
	bowl_button.pressed.connect(_bowl)
	controls.add_child(bowl_button)

	hit_button = Button.new()
	hit_button.text = "HIT"
	hit_button.custom_minimum_size = Vector2(220, 82)
	hit_button.add_theme_font_size_override("font_size", 28)
	hit_button.disabled = true
	hit_button.add_theme_font_size_override("font_size", 28)
	hit_button.pressed.connect(_hit)
	controls.add_child(hit_button)

func _bowl() -> void:
	if ball_active:
		return
	if balls >= 6:
		_new_over()
		return

	bowl_button.disabled = true
	hit_button.disabled = false
	shot_played = false
	shot_quality = 0.0
	ball_node.position = Vector3(randf_range(-0.3, 0.3), 1.35, -8.0)
	ball_velocity = Vector3(randf_range(-0.65, 0.65), randf_range(1.0, 2.0), 9.5)
	ball_active = true
	bowler.rotation_degrees.x = -12
	_set_message("Ball coming — tap HIT!")

func _hit() -> void:
	if not ball_active or shot_played:
		return
	shot_played = true
	hit_button.disabled = true
	var timing := clampf(1.0 - absf(ball_node.position.z - 1.5) / 7.0, 0.2, 1.0)
	shot_quality = timing
	ball_velocity = Vector3(randf_range(-5.0, 5.0), 5.5 + timing * 5.0, 13.0 + timing * 9.0)
	_set_message("Excellent timing!" if timing > 0.72 else "Shot played!")

func _finish_delivery() -> void:
	if not ball_active:
		return
	ball_active = false
	balls += 1
	bowl_button.disabled = false
	hit_button.disabled = true

	var distance := Vector2(ball_node.position.x, ball_node.position.z - 7.0).length()
	var scored := 0
	var wicket_fell := false

	if shot_played:
		if distance > 31.0:
			scored = 6
		elif distance > 20.0:
			scored = 4
		elif distance > 11.0:
			scored = 2
		else:
			scored = 1
	else:
		if randf() < 0.16:
			wickets += 1
			wicket_fell = true

	runs += scored
	if scored > 0:
		_set_message("%d RUNS!" % scored)
	elif wicket_fell:
		_set_message("WICKET!")
	else:
		_set_message("DOT BALL")

	_update_score()
	ball_node.position = Vector3(0, 0.18, -8)

	if wickets >= 10:
		_set_message("ALL OUT — tap NEW OVER")
		bowl_button.text = "NEW OVER"
	elif balls >= 6:
		_set_message("OVER FINISHED — tap NEW OVER")
		bowl_button.text = "NEW OVER"

func _new_over() -> void:
	balls = 0
	wickets = 0
	bowl_button.text = "BOWL"
	bowl_button.disabled = false
	hit_button.disabled = true
	_update_score()
	_set_message("New over — tap BOWL")

func _update_score() -> void:
	score_label.text = "BOUNDARY XI    %d/%d    %d.%d overs" % [runs, wickets, int(balls / 6), balls % 6]

func _set_message(value: String) -> void:
	if is_instance_valid(message_label):
		message_label.text = value

func _make_box(label: String, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
	var item := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	item.mesh = mesh
	item.position = pos
	item.name = label
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	item.material_override = mat
	add_child(item)
	return item

func _make_cylinder(label: String, pos: Vector3, radius: float, height: float, color: Color) -> MeshInstance3D:
	var item := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	item.mesh = mesh
	item.position = pos
	item.name = label
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	item.material_override = mat
	add_child(item)
	return item

func _make_box_child(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
	var item := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	item.mesh = mesh
	item.position = pos
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	item.material_override = mat
	parent.add_child(item)
	return item

func _make_sphere_child(parent: Node3D, pos: Vector3, scale_value: Vector3, color: Color) -> MeshInstance3D:
	var item := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = 0.5
	mesh.height = 1.0
	item.mesh = mesh
	item.position = pos
	item.scale = scale_value
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	item.material_override = mat
	parent.add_child(item)
	return item
