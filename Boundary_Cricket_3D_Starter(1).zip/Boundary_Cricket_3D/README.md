# Boundary Cricket — 3D Prototype

This is the first playable 3D prototype for the Boundary Cricket project, built with Godot 4.3+.

## Included
- 3D cricket ground, pitch, boundary markers and wickets
- Simple 3D batsman and bowler models
- Ball movement with gravity and bounce
- Touch-friendly **BOWL** and **HIT** controls
- Basic runs, wickets and over counter
- Godot Compatibility renderer for mobile-oriented rendering

## Open the project
1. Install Godot 4.3 or newer on a computer.
2. Extract this ZIP.
3. In Godot, choose **Import** and select this folder's `project.godot`.
4. Press **F6** or the Play button to run.

## Android APK
An Android export requires Godot's Android export templates, Android SDK, Java SDK and an Android export preset. This ZIP is the game project source, not a compiled APK. The user currently has an Android phone only, so the next stage is setting up a cloud build workflow.

## Honest project status
This is an early prototype, not a WCC2/WCC3-level commercial game. It uses simple placeholder 3D models and basic ball physics. More work is needed for proper player animations, fielders, bowling variations, match modes, audio, menus, performance testing and polished graphics.
